#include "DxLib.h"
#include "SceneTitle.h"
#include "SceneTest.h"

SceneTitle::SceneTitle():
	m_frameCount(0)
{
}

SceneTitle::~SceneTitle()
{
}

void SceneTitle::Init()
{
}

std::shared_ptr<SceneBase> SceneTitle::Update()
{
	m_frameCount++;

	if (m_frameCount >= 1 * 60)
	{
		//SceneTest�ɐ؂�ւ�
		//SceneTest�̃��������m�ۂ��Ă��̃|�C���^��Ԃ�
		return std::make_shared<SceneTest>();
	}

	return shared_from_this();
}

void SceneTitle::Draw()
{
	DrawCircle(640, 360, 20, 0xffffff, true);

	DrawFormatString(0, 16, 0xffffff, "%d", m_frameCount);

	DrawString(0, 0, "SceneTitle", 0xffffff);
}

void SceneTitle::End()
{
}
